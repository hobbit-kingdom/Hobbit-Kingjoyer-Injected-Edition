ENG:
To run The Kingjoyer: Injected Edition copy all the files from the folder to the root of the game.
You can find the root by right clicking on the shortcut on your desktop and selecting
open file location.

After that simply run Setup.bat and you will see a new shortcut appear on your desktop. Enjoy!

TO RUN THE MENU PRESS NUMPAD 3 while in the game to open and to close the menu.

If your screen resolution is different than 1920x1080, then go to dxwnd folder
and then run dxwnd.exe with admin rights. After that right click on The Hobbit icon and select modify.

At the bottom you will see the screen resolution change it accordingly to your screen. 

---------------------------------------------------------------------
RUS:
Чтобы запустить The Kingjoyer: Injected Edition, скопируйте все файлы из папки в корень игры.
Вы можете найти корень, щелкнув правой кнопкой мыши по ярлыку на рабочем столе и выбрав
открыть местоположение файла.

После этого просто запустите Setup.bat, и вы увидите новый ярлык на рабочем столе. Наслаждайтесь!

ЧТОБЫ ОТКРЫТЬ МЕНЮ НАЖМИТЕ 3 на НАМПАДЕ во время того как вы находитесь в игре. Чтобы закрыть тоже нажмите НАМПАД 3.

Если разрешение вашего экрана отличается от 1920x1080, то перейдите в папку dxwnd
и запустите dxwnd.exe с правами администратора. После этого щелкните правой кнопкой мыши по значку 
The Hobbit и выберите «Изменить».

Внизу вы увидите, как разрешение экрана изменится в соответствии с вашим экраном.

--------------------------------------------------------------------

DxWnd was downloaded from here: https://sourceforge.net/projects/dxwnd/

Hobbit Technical Chat: discord.gg/invite/RMV7haPMkh

