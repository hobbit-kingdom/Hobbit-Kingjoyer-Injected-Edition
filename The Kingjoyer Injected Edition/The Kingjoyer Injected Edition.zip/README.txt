ENG:
Please make sure you are using Unpacked Edition of The Hobbit so skinchanger works as expected. 
You can get it here: https://github.com/hobbit-kingdom/hobbit-versions/releases

Otherwise you can proceed with Clean Version of The Hobbit. 

To run The Kingjoyer: Injected Edition copy all the files from the folder to the root of the game.
You can find the root by right clicking on the shortcut on your desktop and selecting
open file location.

After that simply run Setup.bat and you will see a new shortcut appear on your desktop. Enjoy!

If your screen resolution is different than 1920x1080, then go to dxwnd folder
and then run dxwnd.exe with admin rights. After that right click on The Hobbit icon and select modify.

At the bottom you will see the screen resolution change it accordingly to your screen. 

If you want to change some keybinds open the file called keybinds.ini and change them there.

To OPEN THE KINGJOYER press TAB on your keyboard while in the game. 

Only these keybinds are currently supported:

developerMode
fps60
renderVolumes
polyCache
renderLoadTriggers
renderTriggers
renderWater
renderWeb
renderRopes
renderLeaves
renderChests
renderLevers
renderBilbo
renderLights
renderEffects
breakway
boulderRun
renderSkybox
renderSavePedestal
renderPushBoxes
renderRigidInstances
renderPlaySurface
renderGeometry
setTeleportPoint
teleport


---------------------------------------------------------------------
RUS:
Убедитесь, что вы используете распакованую версию (unpacked edition) хоббита, чтобы работал skinchanger.
Вы можете скачать ее здесь: https://github.com/hobbit-kingdom/hobbit-versions/releases

Если вам не нужен скинчейнджер, то можете использовать обычную версию (clean edition).

Чтобы запустить The Kingjoyer: Injected Edition, скопируйте все файлы из папки в корень игры.
Вы можете найти корень, щелкнув правой кнопкой мыши по ярлыку на рабочем столе и выбрав
открыть местоположение файла.

После этого просто запустите Setup.bat, и вы увидите новый ярлык на рабочем столе. Наслаждайтесь!

Если разрешение вашего экрана отличается от 1920x1080, то перейдите в папку dxwnd
и запустите dxwnd.exe с правами администратора. После этого щелкните правой кнопкой мыши по значку 
The Hobbit и выберите «Изменить».

Внизу вы увидите, как разрешение экрана изменится в соответствии с вашим экраном.

Если вы хотите изменить некоторые сочетания клавиш, откройте файл keybinds.ini и измените их там.

Чтобы ОТКРЫТЬ KINGJOYER, нажмите клавишу TAB на клавиатуре во время игры.

Только эти горячие клавиши сейчас доступны:
developerMode
fps60
renderVolumes
polyCache
renderLoadTriggers
renderTriggers
renderWater
renderWeb
renderRopes
renderLeaves
renderChests
renderLevers
renderBilbo
renderLights
renderEffects
breakway
boulderRun
renderSkybox
renderSavePedestal
renderPushBoxes
renderRigidInstances
renderPlaySurface
renderGeometry
setTeleportPoint
teleport


--------------------------------------------------------------------

DxWnd was downloaded from here: https://sourceforge.net/projects/dxwnd/

Hobbit Technical Chat: discord.gg/invite/RMV7haPMkh

